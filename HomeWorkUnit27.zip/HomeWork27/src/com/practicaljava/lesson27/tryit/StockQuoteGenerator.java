package com.practicaljava.lesson27.tryit;



	import java.rmi.*;
	import java.rmi.server.*;
	import java.util.ArrayList;
	public class StockQuoteGenerator extends UnicastRemoteObject  {
	private String price=null;
	private ArrayList<String> nasdaqSymbols = new ArrayList<String>();
	public StockQuoteGenerator() throws RemoteException {
	super();
	// Define some hard-coded NASDAQ symbols
	nasdaqSymbols.add("AAPL");
	nasdaqSymbols.add("MSFT");
	nasdaqSymbols.add("YHOO");
	nasdaqSymbols.add("AMZN");
	nasdaqSymbols.add("MOT");
	}
	public String getQuote(String symbol)
	throws RemoteException {
	if(nasdaqSymbols.indexOf(symbol.toUpperCase()) != -1) {
	// Generate a random price for valid symbols
	price = (new Double(Math.random()*100)).toString();
	}
	else price="We dont know this price, sorry =(";
	return price;
	}
	public ArrayList<String> getNasdaqSymbols()throws RemoteException {
	return nasdaqSymbols;
}
}
