import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

class EmployeeList {
	
public int  empNo;
 
  public static void main(String argv[]) {
   Connection conn=null;
   Statement stmt=null;
   ResultSet rs=null;

   

   try {
    // Load the JDBC driver  
	// This can be skipped for Derby, but derbyclient.jar has to be in the CLASSPATH   
    // Class.forName("org.apache.derby.jdbc.ClientDriver");
 
    conn = DriverManager.getConnection( "jdbc:derby://localhost:1527/Lesson22"); 

    // Build an SQL String 
    String sqlQuery = "SELECT * from Employee"; 
		
    // Create a Statement object
    stmt = conn.createStatement(); 

    // Execute SQL and get obtain the ResultSet object
    rs = stmt.executeQuery(sqlQuery);  

    // Process the result set - print Employees
    ArrayList myData = new ArrayList();
   
    while (rs.next()){
  System.out.println();
    	 int empNo = rs.getInt("EMPNO");
       	 String eName = rs.getString("ENAME");
         String job = rs.getString("JOB_TITLE");
        myData.add(empNo);
        myData.add(eName);
        myData.add(job);
        System.out.print(" "+myData.toString());
	
    }

   } catch( SQLException se ) {
      System.out.println ("SQLError: " + se.getMessage ()
           + " code: " + se.getErrorCode ());

   } catch( Exception e ) {
      System.out.println(e.getMessage()); 
      e.printStackTrace(); 
   } finally{
       // clean up the system resources
       try{
	   rs.close();     
	   stmt.close(); 
	   conn.close();  
       } catch(Exception e){
           e.printStackTrace();
       } 
   }
}

}