public class Order2 {
    public int orderID;
    public String stockSymbol;
    public String quantity;
    public float price;
    
    public Order2(int id, String stockSymbol, String eName, float price){
    	orderID=id;
    	this.stockSymbol=stockSymbol;
    	this.quantity=eName;
    	this.price=price;
    }
}
