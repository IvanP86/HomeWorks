import java.awt.Color;
import java.awt.Font;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JApplet;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;

import java.util.Random;

public class TicTacToeApplet extends JApplet implements MouseListener
{
    private static final String PLAYERX = "Gamer";
    private static final String PLAYERO = "AI";
	
    private String playerName = PLAYERX;
	
    private javax.swing.JLabel playerNumber;
    private java.awt.Panel buttonsPanel;
    private JButton[] buttons;
    private JButton buttonPlayNewGame;
	
	

    public void init(){
        initComponents();
    }

    private void initComponents(){
        buttonsPanel = new java.awt.Panel();
     
       playerNumber = new javax.swing.JLabel(playerName, SwingConstants.CENTER);
	   Font buttonFont = new Font("Times New Roman", Font.PLAIN, 60);
	   buttonsPanel.setLayout(new java.awt.GridLayout(4, 3));
       buttons = new JButton[9];
        
       for (int i = 0; i < 9; i++) {
		buttons[i] = new JButton();
		buttons[i].addMouseListener(this);
		buttons[i].setFont(buttonFont);
		buttons[i].setBackground(Color.WHITE);
		buttonsPanel.add(buttons[i]);
	   }
   
        buttonsPanel.add(playerNumber);
        buttonPlayNewGame = new JButton("Play Again");
		buttonPlayNewGame.addMouseListener(this);
	    buttonsPanel.add(buttonPlayNewGame);
        add(buttonsPanel);
    }
	
    private void setPlayerName(String playerName){
        this.playerName = playerName;
        playerNumber.setText("Your turn. ");
    }
	
    private void reset(){
      	
    	for (int i = 0; i < 9; i++) {
    	buttons[i].addMouseListener(this);
		buttons[i].setText("");
		buttons[i].setBackground(Color.WHITE);	
		}
        setPlayerName(PLAYERX);
      
    }
	
   public void checkForWinner(){
	
        String [] str = {"OK"};
          if(findThreeInARow()){
        	
           String winnerName=(playerName == PLAYERX)?PLAYERX:PLAYERO;
            if (winnerName==PLAYERX) {
            JOptionPane.showOptionDialog(this, winnerName.concat(" won!!! Congratulations!!!  "),
       		"Congratulations!", JOptionPane.YES_OPTION, JOptionPane.PLAIN_MESSAGE, null, str, "OK");
          }
           else {
        	   JOptionPane.showOptionDialog(this, winnerName.concat(" won!!! Try again!!! "),
               		"Congratulations!", JOptionPane.YES_OPTION, JOptionPane.PLAIN_MESSAGE, null, str, "OK");
        	   
           }
 
            for(int i=0;i<9;i++){
            buttons[i].removeMouseListener(this);	
            }
            
        }
   }
   public void AiTurn(){
	   Random rand = new Random();
	  int i=rand.nextInt(9);

	 if (buttons[i].getText()==""){

     	if (!findThreeInARow()){
     	
		 buttons[i].setText("O");
		
     	}
       checkForWinner();
	   setPlayerName(PLAYERX);
	 }
	 else {
          AiTurn();
   	 }
   }
    
	
    public void mouseClicked(MouseEvent e) {
        javax.swing.JButton currentButton = (JButton)e.getComponent();
        if (currentButton.getText() == ""){
        
            currentButton.setText("X");
            checkForWinner();
            setPlayerName(PLAYERO); 
            if (!findThreeInARow()){
              AiTurn();}
            
        }
        if (currentButton == buttonPlayNewGame ) {
    		
    			reset();
    		
    	}
     
    }
   
	public void mousePressed(MouseEvent e) {
	}

	public void mouseReleased(MouseEvent e) {
	}

	public void mouseEntered(MouseEvent e) {
	}

	public void mouseExited(MouseEvent e) {
	}
	
    private boolean findThreeInARow(){
    	
	    if ((buttons[0].getText() == buttons[1].getText() && buttons[1].getText() == buttons[2].getText() && buttons[1].getText() != "")) {
	    		
	    	buttons[0].setBackground(Color.ORANGE);buttons[1].setBackground(Color.ORANGE);buttons[2].setBackground(Color.ORANGE);
	    	return true;
	    }
	    else 
	 
	    if	(buttons[3].getText() == buttons[4].getText() && buttons[4].getText() == buttons[5].getText() && buttons[3].getText() != "") {
	    	buttons[3].setBackground(Color.ORANGE);
	    	buttons[4].setBackground(Color.ORANGE);
	    	buttons[5].setBackground(Color.ORANGE);
	    	return true;
	    }
	     else 	
	     if   (buttons[6].getText() == buttons[7].getText() && buttons[7].getText() == buttons[8].getText() && buttons[6].getText() != "") {
	    	 buttons[6].setBackground(Color.ORANGE);buttons[7].setBackground(Color.ORANGE);buttons[8].setBackground(Color.ORANGE);
		    	return true;
	     }
	     else 
          if  (buttons[0].getText() == buttons[3].getText() && buttons[3].getText() == buttons[6].getText() && buttons[0].getText() != "") {
        	  buttons[0].setBackground(Color.ORANGE);buttons[3].setBackground(Color.ORANGE);buttons[6].setBackground(Color.ORANGE);
  	    	return true;
          }
          else 
          
         if   (buttons[1].getText() == buttons[4].getText() && buttons[4].getText() == buttons[7].getText() && buttons[1].getText() != "") {
        	 buttons[1].setBackground(Color.ORANGE);buttons[4].setBackground(Color.ORANGE);buttons[7].setBackground(Color.ORANGE);
 	    	return true;
         }
         else  
         if   (buttons[2].getText() == buttons[5].getText() && buttons[5].getText() == buttons[8].getText() && buttons[2].getText() != "") {
        	 buttons[2].setBackground(Color.ORANGE);buttons[5].setBackground(Color.ORANGE);buttons[8].setBackground(Color.ORANGE);
 	    	return true;
         }
         else
         if   (buttons[0].getText() == buttons[4].getText() && buttons[4].getText() == buttons[8].getText() && buttons[0].getText() != "") {
        	 buttons[0].setBackground(Color.ORANGE);buttons[4].setBackground(Color.ORANGE);buttons[8].setBackground(Color.ORANGE);
 	    	return true;
         }
         else 
         if   (buttons[2].getText() == buttons[4].getText() && buttons[4].getText() == buttons[6].getText() && buttons[2].getText() != "") {
        
        	 buttons[2].setBackground(Color.ORANGE);buttons[4].setBackground(Color.ORANGE);buttons[6].setBackground(Color.ORANGE);
 	    	return true;
         } 
         else return false;
       
	    
	
	    	
	     	
	   
    }
}