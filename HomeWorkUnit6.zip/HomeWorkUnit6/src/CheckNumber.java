import javax.swing.JOptionPane;


public class CheckNumber {

	public static void main(String[] args) {
		
		String text,str,str2,str3;
		
	
		int i,a;
		text=JOptionPane.showInputDialog("Enter your credit card number: ");
	
		a= text.length();
	
		str2="";
		for (i=0;i<a;i++){
			
					str=""+text.charAt(i);
					switch(str){
					
					
	
					case "0":					
					case "1":					
					case "2":					
					case "3":					
					case "4":					
					case "5":
					case "6":						
					case "7":					
					case "8":					
					case "9":
						
						str2=str2+str;
							
					break;
									
					}
					
	  } 
				

		str3="We take all money from: \n"+str2;
		JOptionPane.showMessageDialog(null,str3);
		
	}

  }
