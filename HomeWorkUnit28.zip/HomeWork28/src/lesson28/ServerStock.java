package lesson28;

import java.util.ArrayList;



public class ServerStock {
 

   private String price;
   private String symbol;
   private ArrayList<String> nasdaqSymbols = new ArrayList<String>();
   public ServerStock() {
  
      nasdaqSymbols.add("AAPL");
      nasdaqSymbols.add("MSFT");
      nasdaqSymbols.add("YHOO");
      nasdaqSymbols.add("AMZN");
      nasdaqSymbols.add("MOT"); 
   }
 
   public String getPrice() {
      return price;
   }
   
   public String getSymbol(){
	   return symbol;
   }
   
   public void setsymbol(String symbol) {
         this.symbol=symbol;
         if(nasdaqSymbols.indexOf(symbol.toUpperCase()) != -1) {
      // Generate a random price for valid symbols
         price = (new Double(Math.random()*100)).toString();
         }
     else price="wrong symbols, sorry =(";
    
   }
   
   public ArrayList<String> getNasdaqSymbols() {
	   return nasdaqSymbols;
   }
   
  
   
}
