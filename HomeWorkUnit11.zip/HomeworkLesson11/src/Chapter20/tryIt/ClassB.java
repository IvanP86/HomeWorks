package Chapter20.tryIt;
class ClassB extends Thread{
Updatable parent = null;
ClassB(Updatable caller){
parent = caller; 
}
public ClassB() {
	// TODO Auto-generated constructor stub
}
public void run(){

parent.setData("Economy is recovering...");
System.out.println("Economy");
 synchronized (parent){
parent.notify(); 
} 
}

}