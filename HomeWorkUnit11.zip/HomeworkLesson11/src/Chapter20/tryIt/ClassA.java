package Chapter20.tryIt;


	public class ClassA implements Updatable{
		private String marketNews;


		ClassA(){
	    setData();
		}

		public void setData (String news){
		marketNews = news;
		System.out.println(marketNews);
		}
		
		
	 public static void main(String args[]){
		ClassA nm= new ClassA();
	
	 }
	@Override
	public void setData() {

		ClassB myB=new ClassB(this);
		myB.start();
		synchronized(this) {
		try {
			wait();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
		
		}
	
		
	}
	
	
	