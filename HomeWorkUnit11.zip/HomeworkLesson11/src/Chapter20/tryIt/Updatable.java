package Chapter20.tryIt;

public interface Updatable {
void setData();

void setData(String caller);
}
