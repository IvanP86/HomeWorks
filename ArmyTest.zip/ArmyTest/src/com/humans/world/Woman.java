package com.humans.world;

public class Woman implements Human{
 private String name;
 
 
  public Woman(String name){
	  this.name=name;
	  
                           }
  public boolean checkingAge(int age){
	  System.out.print("Sorry, army not for you,  "+name+" , ");
	  System.out.println(age+" years old");
		  return false;
                                     }
                     }
