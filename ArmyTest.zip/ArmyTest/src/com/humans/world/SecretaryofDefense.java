package com.humans.world;

public class SecretaryofDefense implements Human{

	 private String name;
	 
	 
	  public SecretaryofDefense (String name){
		  this.name=name;
		  
	                           }
	  public boolean checkingAge(int age){
		  System.out.println("We happy to see you again, "+name+"!!");
			  return true;
	                                     }
	                     }
