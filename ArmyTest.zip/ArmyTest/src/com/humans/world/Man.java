package com.humans.world;

public class Man implements Human {
 private String name;
  public Man (String name) {
	  this.name=name;
  }
  
  
    public boolean checkingAge(int age){
    	if (ARMY_AGE<=age)  {
    		  if (age<CRITICAL_AGE){
    			  System.out.println("You in the ARMY, "+name+" , "+age+" years old ");
    		                       }
    		  else { 
    			  System.out.println("You too old for us, "+name+" , "+age+" years old ");
    			  return false;
    		       }
    		
    		return true;    }
    	
    	else {
    		System.out.println("Army not for you yet, "+name+" we'll come to you after "+(ARMY_AGE-age)+" years");
    		return false;
    	     }
    	                                 }
                                   }

