package com.humans.world;

 public interface Human {
		int ARMY_AGE=18;
		int CRITICAL_AGE=27;
		
		 boolean checkingAge(int age);
	}
 
