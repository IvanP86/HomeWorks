import java.util.Random;

import com.humans.world.*;

public class TestRecruits {

	public static void main(String[] args) {
	  
		Human recruiter[] = new Human[3];
		recruiter[0] = new Man("Adam");
		recruiter[1] = new Woman("Eva");
		recruiter[2] = new SecretaryofDefense("MrShoigu");
		Random rand = new Random();
		for (Human p: recruiter){
			
				p.checkingAge(rand.nextInt(100));
 		}

	}

}
