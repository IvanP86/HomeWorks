import java.io.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipInputStream;


public class Zippo {
	static boolean eof;
	private static ZipEntry x;
	static FileInputStream  myFile=null;
	static ZipInputStream zipFile;

	  public static void main(String args[]) 
      {
		 
	
		  try{
		  
		 myFile = new  FileInputStream("zipzip.zip");
		 zipFile = new ZipInputStream(myFile);
	
		 while (!eof) {
		
			x=zipFile.getNextEntry();
	
             int byteValue = zipFile.read();
             if (!(x==null)){
             System.out.print(x + " ");
             }
            if (byteValue  ==-1)
                eof = true;
     
        }
		  
		  } catch (IOException e){
			  System.out.println("Could not read file: " + 
                      e.toString());
			  
		  }finally {
			  
	
			      try {
					zipFile.close();
					  myFile.close();
				} catch (IOException e) {
					
					e.printStackTrace();
				}
			       
	    
		}
		  
		  
		  
      }
}
