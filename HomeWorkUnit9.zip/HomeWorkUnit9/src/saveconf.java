
public class saveconf implements java.io.Serializable{
int xx;
int yy;
String colcol;
	
}
