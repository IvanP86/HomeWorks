import java.awt.event.*;

import javax.swing.*;

import java.io.*;
import java.awt.GridLayout;
import java.io.FileInputStream;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Vector;


	public class Preference extends JFrame implements ActionListener{
		
    JLabel xsize1;
    JTextField xsize2 = new JTextField(15);
    JLabel ysize1=new JLabel("y size: ");
    JTextField ysize2 = new JTextField(2);
    JLabel color = new JLabel("Color: ");
    
  
    String[] states = { "Green", "Yellow" };
    
    
    JComboBox chState = new JComboBox(states);

    JLabel mes = new JLabel("Message: ");
    JTextField txtmes = new JTextField(10);
    JButton save = new JButton("Save");
  
    
    Preference() {
        xsize1 = new JLabel("x size: ");
        GridLayout gr = new GridLayout(5,2,1,1);
        setLayout(gr);

        add(xsize1);
        add(xsize2);
        add(ysize1);
        add(ysize2);
        add(color);
        add(chState);
        add(mes);
        add(txtmes);
        add(save);
   
        save.addActionListener(this);
 
	this.addWindowListener(new WindowAdapter() {
	    public void windowClosing(WindowEvent e) {
                 System.out.println("Good bye!");
               
		    System.exit(0);
	    }}); 
    } 

    public void actionPerformed(ActionEvent evt) {
       Object source = evt.getSource();
        if (source == save ){
         
             try{
               int x =Integer.parseInt(xsize2.getText());
               int y = Integer.parseInt(ysize2.getText());
               String col = (String)chState.getSelectedItem();

 
 
 saveconf conf = new saveconf();
 conf.xx =x;
 conf.yy =y; 
 conf.colcol =col;
 
 FileOutputStream fOut=null;
 ObjectOutputStream oOut=null;
 
 

 fOut = new  FileOutputStream("savedconf.ser");

 oOut = new ObjectOutputStream(fOut);

 oOut.writeObject(conf); 

 oOut.flush();
 oOut.close();
 fOut.close();
 
 

 
             }catch(NumberFormatException e){
                 txtmes.setText("Non-Numeric Data");
             }catch (Exception e){
                txtmes.setText(e.getMessage());
             }
             
        }
             

             
          
  
        
    }
    
 
  
public static void deserialization() {
	
	
	FileInputStream fIn=null;
    ObjectInputStream oIn=null;
   saveconf saveconf1 = null;

    try{   
  fIn = new  FileInputStream("savedconf");

  oIn = new ObjectInputStream(fIn);

 saveconf1=(saveconf)oIn.readObject();

     }catch (ClassNotFoundException cnf){
	   cnf.printStackTrace();
     } catch (IOException e){
	      try{ 
     oIn.close();
     fIn.close();
	  }catch (IOException ioe){
		  ioe.printStackTrace();
	  }
     }finally{
	   if (oIn != null){
	    try{ 
	        oIn.close();
	        fIn.close();
		  }catch (IOException e1){
			  e1.printStackTrace();
		  }
	   }  
}

 System.out.println(saveconf1.xx);
System.out.println("The Employee  object has been deserialized from BestEmployee.ser");
	

} 
    public static void main(String args[]) {
    	String fileName = "savedconf.ser";
    	if ((new File(fileName)).exists()) {
    	
    		
    		new ClassB();
    	} else {
    		 Preference saveFrame = new Preference();
  	       saveFrame.setSize(400,150);
  	       saveFrame.setVisible(true);
    		
    	
    	}
 
      
    }
}


	
