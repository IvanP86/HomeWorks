import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JFrame;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

import javax.swing.JLabel;
class ClassB extends JFrame{
	public String z;
	public  ClassB(){
		  FileInputStream fIn=null;
	       ObjectInputStream oIn=null;
	       saveconf bestEmp = null;
	  
	    try{   
	     fIn = new  FileInputStream("savedconf.ser");

	     oIn = new ObjectInputStream(fIn);

	     bestEmp=(saveconf)oIn.readObject();
	 
	   }catch (ClassNotFoundException cnf){
		   cnf.printStackTrace();
	   } catch (IOException e){
		  try{ 
	        oIn.close();
	        fIn.close();
		  }catch (IOException ioe){
			  ioe.printStackTrace();
		  }
	   }finally{
		   if (oIn != null){
		    try{ 
		        oIn.close();
		        fIn.close();
			  }catch (IOException e1){
				  e1.printStackTrace();
			  }
		   }  
		
		

	 z = bestEmp.colcol;

	
		setSize(bestEmp.xx,bestEmp.yy);
		
    	
    	
    	// Adding a button
    	JLabel myLable=new JLabel("HeLLo");
  
    	
    	switch(z){
    	case "Green":
    		myLable.setForeground(Color.GREEN);
    	break;
    	case "Yellow":
    		myLable.setForeground(Color.YELLOW);
    	break;	
    	}
    	
  
    
    	add(myLable);
    
         
    	setTitle("Hello World");
    	setVisible(true); 

     	this.addWindowListener(new WindowAdapter() {
     	    public void windowClosing(WindowEvent e) {
                      System.out.println("Good bye!");
     		    System.exit(0);
     	    }});
	   }
	}
	
	
  public static void main(String args[]){
       
  
  new ClassB();
   

  } 
}